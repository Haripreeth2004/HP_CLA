#!/bin/tcsh -f
#-------------------------------------------
# qflow exec script for project /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA
#-------------------------------------------

# /usr/local/share/qflow/scripts/synthesize.sh /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA/source/carry_lookahead_adder_4bit.v || exit 1
# /usr/local/share/qflow/scripts/placement.sh -d /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
# /usr/local/share/qflow/scripts/vesta.sh  /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
# /usr/local/share/qflow/scripts/router.sh /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
# /usr/local/share/qflow/scripts/vesta.sh  -d /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
# /usr/local/share/qflow/scripts/migrate.sh /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
# /usr/local/share/qflow/scripts/drc.sh /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
# /usr/local/share/qflow/scripts/lvs.sh /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
/usr/local/share/qflow/scripts/gdsii.sh /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
# /usr/local/share/qflow/scripts/cleanup.sh /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
# /usr/local/share/qflow/scripts/display.sh /media/hari-the-geth/HPCORE/Programming_with_FPGA_using_HDL/Projects/CLA carry_lookahead_adder_4bit || exit 1
